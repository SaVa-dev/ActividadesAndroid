package com.example.activity7

import android.os.Bundle
import android.transition.AutoTransition
import android.transition.Scene
import android.transition.Transition
import android.transition.TransitionManager
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var transition: Transition
    lateinit var scene1: Scene
    lateinit var scene2: Scene
    lateinit var boton: Button
    var start = true

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        boton = findViewById(R.id.next)
        var mSceneRoot: ViewGroup = findViewById(R.id.scene_root)

        scene1 = Scene.getSceneForLayout(mSceneRoot, R.layout.first_movie, this)
        scene2 = Scene.getSceneForLayout(mSceneRoot, R.layout.second_movie, this)

        transition = AutoTransition()
        transition.duration = 1000
        transition.setInterpolator(AccelerateDecelerateInterpolator())


        boton.setOnClickListener {
            ChangeScene()
        }

    }

    fun ChangeScene() {
        if (start) {
            TransitionManager.go(scene2, transition)
            start = false
        } else {
            TransitionManager.go(scene1, transition)
            start = true
        }
    }

    fun ChangeScene(view: View) {}

}