package com.example.actividad10

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var myService: MyService2
    private var isBounded: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var serviceConnection: ServiceConnection = object : ServiceConnection {
            override public fun onServiceConnected(componentName: ComponentName, iBinder: IBinder) {
                val myLocalBinder = iBinder as MyService2.MyLocalBinder

                myService = myLocalBinder.service

                isBounded = true
            }

            override fun onServiceDisconnected(p0: ComponentName?) {
                isBounded = false
            }
        }
        var intent: Intent = Intent(this, MyService2::class.java)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    public fun InitAction(view: View) {
        var intent: Intent = Intent(this, MyIntentService::class.java)
        startService(intent)
    }

    public fun InitAction2(view: View) {
        var intent: Intent = Intent(this, MyService::class.java)
        startService(intent)
    }

    public fun InitAction3(view: View) {
        var time: String = myService.currentTime
        var textView: TextView = findViewById(R.id.textView)
        textView.setText(time)
    }
}