package com.example.actividad10;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyService extends Service {

    private static final String TYPE = "MyService";

    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TYPE, "Iniciamos el servicio");

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                long startTime = System.currentTimeMillis();
                long finalTime = startTime + 2_000;

                while (System.currentTimeMillis() < finalTime) {
                    synchronized (this) {
                        try {
                            wait(finalTime - System.currentTimeMillis());
                            Log.i(TYPE, "Servicio en proceso");
                        } catch (Exception e) {

                        }
                    }
                }
            }
        };
        Thread thread = new Thread(runnable);
        thread.start();
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        Log.i(TYPE, "metodo onDestroy() llamado");
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind (Intent intent) {
        return null;
    }
}
