package com.example.actividad3

class BotonSeleccionado {

    companion object {
        var boton: String = "Selec. en navigation bar"
    }
}