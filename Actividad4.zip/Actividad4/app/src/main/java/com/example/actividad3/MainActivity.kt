package com.example.actividad3

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.example.actividad3.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private lateinit var boton: Button
    private lateinit var resultLauncher: ActivityResultLauncher<Intent>
    private lateinit var imagen: ImageView
    var selectedButton: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.appBarMain.toolbar)

        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        val rotate1 = RotateAnimation(
            0f,
            -360f,
            Animation.RELATIVE_TO_SELF,
            0.5f,
            Animation.RELATIVE_TO_SELF,
            0.5f
        )
        rotate1.duration = 1000
        rotate1.interpolator = AccelerateDecelerateInterpolator()

        val rotate2 = RotateAnimation(
            0f,
            720f * 2f,
            Animation.RELATIVE_TO_SELF,
            0.5f,
            Animation.RELATIVE_TO_SELF,
            0.5f
        )

        rotate2.duration = 4000
        rotate2.interpolator = AccelerateDecelerateInterpolator()

        boton = findViewById(R.id.boton)
        boton.text = BotonSeleccionado.boton
        setContentView(binding.root)

        // Configurar el listener para los elementos del menú
        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.boton_1, R.id.boton_2, R.id.boton_3 -> {

                    selectedButton = when (menuItem.itemId) {
                        R.id.boton_1 -> "onClick"
                        R.id.boton_2 -> "onLongClick"
                        R.id.boton_3 -> "onFocusChange"
                        else -> "null"
                    }

                    selectedButton.let {
                        BotonSeleccionado.boton = selectedButton
                        boton.text = BotonSeleccionado.boton
                        setContentView(binding.root)
                    }
                }

                R.id.nav_close_app -> {
                    finishAffinity()
                }
            }

            // Cerrar el drawer
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        imagen = findViewById(R.id.imagen)
        registrarResultado()


        imagen.setOnClickListener {
            pickImage()
        }

        boton.setOnClickListener {
            if (BotonSeleccionado.boton.contains("onClick")) {
                imagen.startAnimation(rotate1)
            }
        }

        boton.setOnLongClickListener {
            if (BotonSeleccionado.boton.contains("onLongClick")) {
                imagen.startAnimation(rotate2)
            }

            true
        }

        boton.setOnFocusChangeListener { view: View, b: Boolean ->
            if(BotonSeleccionado.boton.contains("onFocusChange")) {
                if (b) {
                    imagen.animate()
                        .translationY(-10F)
                        .scaleY(0.9F)
                        .scaleX(0.9F)
                        .setInterpolator(AccelerateDecelerateInterpolator())
                        .duration = 250
                } else {
                    imagen.animate()
                        .translationY(0F)
                        .scaleY(1F)
                        .scaleX(1F)
                        .setInterpolator(AccelerateDecelerateInterpolator())
                        .duration = 250
                }
            }
        }
    }


    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }



    private fun pickImage() {
        val intent: Intent = Intent(MediaStore.ACTION_PICK_IMAGES)
        resultLauncher.launch(intent)
    }

    private fun registrarResultado() {
        resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                try {
                    val imageUri: Uri? = result.data?.data
                    imagen.setImageURI(imageUri)
                } catch (e: Exception) {
                    Toast.makeText(this, "Imagen no seleccionada", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Operación cancelada", Toast.LENGTH_LONG).show()
            }
        }
    }
}
