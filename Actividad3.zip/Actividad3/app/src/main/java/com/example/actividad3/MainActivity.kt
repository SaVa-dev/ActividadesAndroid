package com.example.actividad3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity() {
        private lateinit var button: Button
        private lateinit var imagen: ImageView
        private lateinit var resultLauncher: ActivityResultLauncher<Intent>
        private lateinit var rotate1: RotateAnimation
        private lateinit var rotate2: RotateAnimation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableEdgeToEdge()

        rotate1 = RotateAnimation(
            0f,
            -360f,
            Animation.RELATIVE_TO_SELF,
            0.5f,
            Animation.RELATIVE_TO_SELF,
            0.5f
        )
        rotate1.duration = 1000
        rotate1.interpolator = AccelerateDecelerateInterpolator()

        rotate2 = RotateAnimation(
            0f,
            720f * 2f,
            Animation.RELATIVE_TO_SELF,
            0.5f,
            Animation.RELATIVE_TO_SELF,
            0.5f
        )

        rotate2.duration = 4000
        rotate2.interpolator = AccelerateDecelerateInterpolator()

        button = findViewById(R.id.boton)
        imagen = findViewById(R.id.imagen)
        registrarResultado()

        imagen.setOnClickListener {
            pickImage()
        }

        button.setOnClickListener {
            imagen.startAnimation(rotate1)
        }

        button.setOnLongClickListener {
            imagen.startAnimation(rotate2)
            true
        }

        button.setOnFocusChangeListener { view: View, b: Boolean ->
            if (b) {
                imagen.animate()
                    .translationY(-10F)
                    .scaleY(0.9F)
                    .scaleX(0.9F)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .duration = 250
            } else {
                imagen.animate()
                    .translationY(0F)
                    .scaleY(1F)
                    .scaleX(1F)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .duration = 250
            }
        }

        button.setOnDragListener()



    }

    private fun pickImage() {
        val intent: Intent = Intent(MediaStore.ACTION_PICK_IMAGES)
        resultLauncher.launch(intent)
    }

    private fun registrarResultado() {
        resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                try {
                    val imageUri: Uri? = result.data?.data
                    imagen.setImageURI(imageUri)
                } catch (e: Exception) {
                    Toast.makeText(this, "Imagen no seleccionada", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Operación cancelada", Toast.LENGTH_LONG).show()
            }
        }
    }
}