package com.example.evidencia2

import android.widget.ImageView

class Location(
    var nombreLugar: String,
    var nombreCiudad: String,
    var longitud: Double,
    var latitud: Double
) {
    companion object {
        var locations: MutableList<Location> = mutableListOf()
        var selectedLocation: Location? = null

        fun addLocation(location: Location) {
            locations.add(location)
        }
    }

    override fun toString(): String {
        return nombreLugar
    }
}
