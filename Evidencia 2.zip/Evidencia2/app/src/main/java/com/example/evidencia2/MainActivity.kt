package com.example.evidencia2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var listView: ListView
    lateinit var addButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        supportActionBar?.hide()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.list_view_ubicaciones)
        listView.adapter = ArrayAdapter<Location>(
            this,
            android.R.layout.simple_list_item_1,
            Location.locations
        )

        addButton = findViewById(R.id.add_button)

        addButton.setOnClickListener {
            startActivity(
                Intent(this, NewPlace::class.java)
            )
        }

        listView.setOnItemClickListener { parent, view, position, id ->
            val selectedLocation = parent.getItemAtPosition(position) as Location
            Location.selectedLocation = selectedLocation // Guardar el objeto seleccionado
            // Aquí puedes hacer lo que necesites con selectedLocation
            val intent = Intent(this, GoogleMaps::class.java)

            println(selectedLocation.latitud)
            startActivity(intent)
        }
    }
}