package com.example.evidencia2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class NewPlace : AppCompatActivity() {
    lateinit var createLocationButton: Button
    lateinit var backButton: ImageButton

    lateinit var lugarText: EditText
    lateinit var ciudadText: EditText
    lateinit var longitudText: EditText
    lateinit var latitudText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        supportActionBar?.hide()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        setContentView(R.layout.activity_new_place)

        createLocationButton = findViewById(R.id.create_location)
        backButton = findViewById(R.id.back)

        lugarText = findViewById(R.id.lugar)
        ciudadText = findViewById(R.id.ciudad)
        longitudText = findViewById(R.id.longitud)
        latitudText = findViewById(R.id.latitud)

        createLocationButton.setOnClickListener {
            val lugar = lugarText.text.toString()
            val ciudad = ciudadText.text.toString()
            val longitud = longitudText.text
                    .toString()
                    .toDouble()
            val latitud = latitudText.text
                    .toString()
                    .toDouble()

            val location = Location(lugar, ciudad, longitud, latitud)

            Location.addLocation(location)
            startActivity(
                Intent(this, MainActivity::class.java)
            )
        }

        backButton.setOnClickListener {
            super.onBackPressed()
        }
    }
}