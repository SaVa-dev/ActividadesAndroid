package com.example.actividad9

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import android.widget.Toast

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "android.provider.Telephony.SMS_RECEIVED") {
            val bundle = intent.extras
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            messages?.forEach { sms ->
                val phoneNumber = sms.originatingAddress
                val messageBody = sms.messageBody

                if (MainActivity.phoneNumbers.contains(phoneNumber)) {
                    Toast.makeText(context, "Mensaje de $phoneNumber: $messageBody", Toast.LENGTH_LONG).show()
                } else {
                    Log.d("SmsReceiver", "Mensaje recibido de $phoneNumber: $messageBody")
                }
            }
        }
    }
}
