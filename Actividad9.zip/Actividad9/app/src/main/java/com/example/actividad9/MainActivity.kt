package com.example.actividad9

import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var editText: EditText

    companion object {
        val phoneNumbers = mutableListOf<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkForSmsReceivePermissions()

        listView = findViewById(R.id.numeros)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, phoneNumbers)
        listView.adapter = adapter
        editText = findViewById(R.id.numero)

        findViewById<Button>(R.id.addPhoneNumberButton).setOnClickListener {
            addPhoneNumber(editText.text.toString())
        }
    }


    private fun addPhoneNumber(phoneNumber: String) {
        phoneNumbers.add(phoneNumber)
        adapter.notifyDataSetChanged()
    }

    private fun checkForSmsReceivePermissions() {
        if (ContextCompat.checkSelfPermission(
                baseContext,
                "android.permission.RECEIVE_SMS"
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            Log.d("adnan", "checkForSmsReceivePermissions: Allowed")
        } else {
            Log.d("adnan", "checkForSmsReceivePermissions: Denied")
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECEIVE_SMS),
                43391
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 43391) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("adnan", "Sms Receive Permissions granted")
            } else {
                Log.d("adnan", "Sms Receive Permissions denied")
            }
        }
    }
}
