package com.example.evidencia1

import android.graphics.drawable.Drawable

class Carrera(
    var nombreCarrera: String,
    var imagen: Drawable,
    var materia: List<Materia>
) {
    override fun toString(): String {
        return nombreCarrera
    }
}