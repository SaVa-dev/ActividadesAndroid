package com.example.evidencia1

class Materia(
    var nombre: String,
    var fecha: String,
    var hora: String,
    var tipo: TipoExamen,
    var bloqueado: Boolean = false
) {
    enum class TipoExamen {
        EN_LINEA,
        PRESENCIAL
    }

    override fun toString(): String {
        return nombre
    }
}
