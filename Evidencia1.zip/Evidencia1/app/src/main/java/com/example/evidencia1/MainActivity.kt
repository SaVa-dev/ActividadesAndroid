package com.example.evidencia1

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.provider.MediaStore.Audio.Radio
import android.text.format.DateFormat
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.DatePicker
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.get
import org.w3c.dom.Text

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var toolbar: Toolbar
    lateinit var spinnerCarreras: Spinner
    lateinit var spinnerMaterias: Spinner
    lateinit var imagenMaterias:  ImageView
    lateinit var texto:           TextView
    lateinit var botonDia:        Button
    lateinit var textoDia:        TextView
    lateinit var botonHora:       Button
    lateinit var textoHora:       TextView
    lateinit var radioButton:     RadioButton

    lateinit var carrera1: Carrera
    lateinit var carrera2: Carrera
    lateinit var carrera3: Carrera
    lateinit var carrera4: Carrera
    lateinit var carreras: List<Carrera>

    override fun onCreate(savedInstanceState: Bundle?) {

        // Typical shit to init everythin'
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        // Inicializar Toolbar por ID
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Inicializar listas
        carreras = crearListaCarreras()

        // Inicializar spinners por ID
        spinnerCarreras = findViewById(R.id.spinnerCarreras)
        val adapter1: ArrayAdapter<Carrera> = ArrayAdapter(
            this,
            R.layout.spinner_element,
            carreras
        )
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCarreras.adapter = adapter1
        spinnerCarreras.onItemSelectedListener = this
        spinnerMaterias = findViewById(R.id.spinnerMaterias)
        actualizarSpinner(carreras[0].materia)
        spinnerMaterias.onItemSelectedListener = this

        // Inicializar imagen por ID
        imagenMaterias = findViewById(R.id.image)
        imagenMaterias.setImageDrawable(carreras[0].imagen)

        // Inicializar texto por ID
        texto = findViewById(R.id.tipoExamen)
        texto.text = "${carreras[0].materia[0].tipo.toString()}"

        // Inicializar hoaihfasdlfjgjc `false`
        botonDia = findViewById(R.id.boton_dia)
        textoDia = findViewById(R.id.textodia)
        botonHora = findViewById(R.id.boton_hora)
        textoHora = findViewById(R.id.textohora)
        textoDia.text = "Día examen: ${carreras[0].materia[0].fecha}"
        textoHora.text = "Hora examen: ${carreras[0].materia[0].hora}"
        botonDia.setOnClickListener {
            val materia = spinnerMaterias.selectedItem as Materia
            if (!materia.bloqueado) {
                openDatePickerDialog()
            } else {
                Toast.makeText(this, "Examen no se puede modificar, está bloqueado.", Toast.LENGTH_LONG).show()
            }
        }
        botonHora.setOnClickListener {
            val materia = spinnerMaterias.selectedItem as Materia
            if (!materia.bloqueado) {
                openTimePickerDialog()
            } else {
                Toast.makeText(this, "Examen no se puede modificar, está bloqueado.", Toast.LENGTH_LONG).show()
            }

        }

        // 10:00 y aun no acabo esto...
        imagenMaterias.setOnClickListener {
            val materia = spinnerMaterias.selectedItem as Materia

            if (!materia.bloqueado) {
                val builder: AlertDialog.Builder = AlertDialog.Builder(this)
                builder
                    .setMessage("¿Qué modalidad quieres que sea el examen?")
                    .setTitle("CAMBIAR EXAMEN")
                    .setPositiveButton("En Linea") { dialog, which ->
                        texto.text = "EN_LINEA"

                        materia.tipo = Materia.TipoExamen.EN_LINEA
                    }
                    .setNegativeButton("Presencial") { dialog, which ->
                        texto.text = "PRESENCIAL"
                        materia.tipo = Materia.TipoExamen.PRESENCIAL
                    }

                val dialog: AlertDialog = builder.create()
                dialog.show()
            } else {
                Toast.makeText(this, "Examen no se puede modificar, está bloqueado.", Toast.LENGTH_LONG).show()
            }
        }

        // RADIO BUTTON Y SAN SE ACABÓ
        radioButton = findViewById(R.id.bloqueado)
        radioButton.setOnClickListener {
            val materia = spinnerMaterias.selectedItem as Materia
            radioButton.isChecked = !materia.bloqueado
            materia.bloqueado = !materia.bloqueado
        }

    }

    // Implementación del método onItemSelected para Spinners
    override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
        when (parent.id) {
            R.id.spinnerCarreras -> {
                val carreraSeleccionada = parent.getItemAtPosition(position) as Carrera
                actualizarSpinner(carreraSeleccionada.materia)
                imagenMaterias.setImageDrawable(carreraSeleccionada.imagen)

            }

            R.id.spinnerMaterias -> {
                val materiaSeleccionada = parent.getItemAtPosition(position) as Materia
                texto.text = materiaSeleccionada.tipo.toString()
                textoDia.text = "Día examen: ${materiaSeleccionada.fecha}"
                textoHora.text = "Hora examen: ${materiaSeleccionada.hora}"
                radioButton.isChecked = materiaSeleccionada.bloqueado
            }
        }
    }

    // Implementación del método onNothingSelected
    override fun onNothingSelected(parent: AdapterView<*>) {
        // TODO: nada, nomás chilla Android Studio si no lo inicializo
    }

    private fun actualizarSpinner(materias: List<Materia>) {
        val materiasAdapter: ArrayAdapter<Materia> = ArrayAdapter(
            this,
            R.layout.spinner_element,
            materias
        )
        materiasAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMaterias.adapter = materiasAdapter
    }

    fun openDatePickerDialog() {
        val datePicker: DatePickerDialog = DatePickerDialog(
            this,
            { _: DatePicker, year: Int, month: Int, day: Int ->
                val fecha = String.format("%02d-%02d-%02d", year, month + 1, day)
                textoDia.text = "Día examen: $fecha"
                val materia = spinnerMaterias.selectedItem as Materia
                materia.fecha = fecha
            },
            2022,
            0,
            15
        )

        datePicker.show()
    }

    fun openTimePickerDialog() {
        val timePicker: TimePickerDialog = TimePickerDialog(
            this,
            { _: TimePicker, hourOfDay: Int, minute: Int ->
                val hora = String.format("%02d:%02d", hourOfDay, minute)
                textoHora.text = "Hora examen: $hora"
                val materia = spinnerMaterias.selectedItem as Materia
                materia.hora = hora
            },
            0,
            0,
            DateFormat.is24HourFormat(this)
        )

        timePicker.show()
    }


    private fun crearListaCarreras(): List<Carrera> {
        carrera1 = Carrera(
            nombreCarrera = "Ingeniería en Sistemas",
            imagen = ContextCompat.getDrawable(this, R.drawable.sistemas)!!,
            materia = listOf(
                Materia("Programación I", "2024-05-15", "10:00", Materia.TipoExamen.PRESENCIAL),
                Materia("Estructuras de Datos", "2024-06-20", "12:00", Materia.TipoExamen.EN_LINEA),
                Materia("Base de Datos", "2024-07-01", "08:00", Materia.TipoExamen.PRESENCIAL, bloqueado = true),
                Materia("Redes", "2024-08-12", "14:00", Materia.TipoExamen.EN_LINEA)
            )
        )

        carrera2 = Carrera(
            nombreCarrera = "Ingeniería Civil",
            ContextCompat.getDrawable(this, R.drawable.civil)!!,
            materia = listOf(
                Materia("Cálculo I", "2024-05-10", "09:00", Materia.TipoExamen.PRESENCIAL),
                Materia("Física", "2024-06-15", "11:00", Materia.TipoExamen.EN_LINEA),
                Materia("Estructuras", "2024-07-05", "13:00", Materia.TipoExamen.PRESENCIAL, bloqueado = true),
                Materia("Topografía", "2024-08-20", "15:00", Materia.TipoExamen.EN_LINEA)
            )
        )

        carrera3 = Carrera(
            nombreCarrera = "Ingeniería Industrial",
            ContextCompat.getDrawable(this, R.drawable.industrial)!!,
            materia = listOf(
                Materia("Gestión de la Producción", "2024-04-30", "08:30", Materia.TipoExamen.PRESENCIAL),
                Materia("Economía", "2024-06-10", "10:30", Materia.TipoExamen.EN_LINEA),
                Materia("Estadística", "2024-07-20", "12:30", Materia.TipoExamen.PRESENCIAL),
                Materia("Logística", "2024-08-01", "14:30", Materia.TipoExamen.EN_LINEA, bloqueado = true)
            )
        )

        carrera4 = Carrera(
            nombreCarrera = "Arquitectura",
            ContextCompat.getDrawable(this, R.drawable.arquitectura)!!,
            materia = listOf(
                Materia("Diseño I", "2024-05-05", "09:45", Materia.TipoExamen.PRESENCIAL),
                Materia("Historia del Arte", "2024-06-25", "11:45", Materia.TipoExamen.EN_LINEA),
                Materia("Estructuras Arquitectónicas", "2024-07-10", "13:45", Materia.TipoExamen.PRESENCIAL),
                Materia("Urbanismo", "2024-08-15", "15:45", Materia.TipoExamen.EN_LINEA, bloqueado = true)
            )
        )
        return listOf(carrera1, carrera2, carrera3, carrera4)
    }
}