package com.example.tema11

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.transition.AutoTransition
import androidx.transition.Scene
import androidx.transition.Transition
import androidx.transition.TransitionManager
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar

    private lateinit var scene1: Scene
    private lateinit var scene2: Scene
    private lateinit var transition: Transition

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val sceneRoot: ViewGroup = findViewById(R.id.scene_root)
        scene1 = Scene.getSceneForLayout(sceneRoot, R.layout.activity_productos, this)
        scene2 = Scene.getSceneForLayout(sceneRoot, R.layout.activity_movimientos, this)
        transition = AutoTransition().setDuration(250).setInterpolator(AccelerateDecelerateInterpolator())
        toolbar.setOverflowIcon(ContextCompat.getDrawable(this, R.drawable.overflow_menu_vertical_svgrepo_com))
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.menu_productos ->   TransitionManager.go(scene1, transition)
            R.id.menu_movimientos -> TransitionManager.go(scene2, transition)
            R.id.menu_exit ->        finish()
        }
        return true
    }
}
