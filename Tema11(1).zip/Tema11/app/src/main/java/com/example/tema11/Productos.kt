package com.example.tema11

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Productos : AppCompatActivity() {
    private lateinit var etCodigo: EditText
    private lateinit var etDescripcion: EditText
    private lateinit var etExistencias: EditText
    private lateinit var etPrecio: EditText

    private lateinit var buttonRegistrar: Button
    private lateinit var buttonBuscar: Button
    private lateinit var buttonModificar: Button
    private lateinit var buttonEliminar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_productos)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.productos)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inicializar Edit Texts
        etCodigo = findViewById(R.id.editTextCodigo)
        etDescripcion = findViewById(R.id.editTextDetalle)
        etExistencias = findViewById(R.id.editTextExistencia)
        etPrecio = findViewById(R.id.editTextPrecio)

        buttonRegistrar = findViewById<Button>(R.id.button)
        buttonBuscar = findViewById<Button>(R.id.button2)
        buttonModificar = findViewById<Button>(R.id.button3)
        buttonEliminar = findViewById<Button>(R.id.button4)

        buttonRegistrar.setOnClickListener {
            registrar() // Call your existing registrar function
        }

        buttonBuscar.setOnClickListener {
            buscar() // Call your existing buscar function

        }

        buttonModificar.setOnClickListener {
            modificar() // Call your existing modificar function
        }

        buttonEliminar.setOnClickListener {
            eliminar() // Call your existing eliminar function
        }
    }

    fun registrar() {
        val admin = AdminSQLiteOpenHelper(
            this,
            "administracion",
            null,
            1
        )
        val baseDeDatos: SQLiteDatabase = admin.writableDatabase

        val codigo: String = etCodigo.text.toString()
        val descripcion: String = etDescripcion.text.toString()
        val precio: String = etPrecio.text.toString()

        if (codigo.isNotEmpty() && descripcion.isNotEmpty() && precio.isNotEmpty()) {
            val registro = ContentValues()

            registro.put("codigo", codigo)
            registro.put("descripcion", descripcion)
            registro.put("precio", precio)

            baseDeDatos.insert("articulos", null, registro)

            baseDeDatos.close()

            etCodigo.setText("")
            etDescripcion.setText("")
            etPrecio.setText("")

            Toast.makeText(this, "Registro exitoso!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show()
        }
    }

    fun buscar() {
        val admin = AdminSQLiteOpenHelper(
            this,
            "administracion",
            null,
            1
        )
        val baseDeDatos: SQLiteDatabase = admin.writableDatabase

        val codigo = etCodigo.text.toString()

        if (codigo.isNotEmpty()) {
            val fila: Cursor = baseDeDatos.rawQuery(
                "SELECT descripcion, precio " +
                        "FROM articulos " +
                        "WHERE codigo = $codigo",
                null
            )



            if (fila.moveToFirst()) {
                etDescripcion.setText(fila.getString(0))
                etPrecio.setText(fila.getString(1))
            } else {
                Toast.makeText(this, "No existe el articulo", Toast.LENGTH_SHORT).show()
            }
            fila.close()
            baseDeDatos.close()
        } else {
            Toast.makeText(this, "Debes introducir el codigo del articulo", Toast.LENGTH_SHORT).show()
        }
    }

    fun eliminar () {
        val admin = AdminSQLiteOpenHelper(
            this,
            "administracion",
            null,
            1
        )
        val baseDeDatos = admin.writableDatabase

        val codigo = etCodigo.text.toString()

        if (codigo.isNotEmpty()) {
            val cantidad = baseDeDatos.delete(
                "articulos",
                "codigo = $codigo",
                null
            )
            baseDeDatos.close()

            etCodigo.setText("")
            etDescripcion.setText("")
            etPrecio.setText("")

            if (cantidad == 1) {
                Toast.makeText(this, "Articulo eliminado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "El articulo no existe", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Debes introducir el codigo del articulo", Toast.LENGTH_SHORT).show()
        }
    }

    fun modificar () {
        val admin = AdminSQLiteOpenHelper(
            this,
            "administracion",
            null,
            1
        )
        val baseDeDatos = admin.writableDatabase

        val codigo = etCodigo.text.toString()
        val descripcion = etDescripcion.text.toString()
        val precio = etPrecio.text.toString()

        if (codigo.isNotEmpty() && descripcion.isNotEmpty() && precio.isNotEmpty()) {
            val registro = ContentValues()
            registro.put("codigo", codigo)
            registro.put("descripcion", descripcion)
            registro.put("precio", precio)

            val cantidad = baseDeDatos.update(
                "articulos",
                registro,
                "codigo = $codigo",
                null
            )

            baseDeDatos.close()

            if (cantidad == 1) {
                Toast.makeText(this, "Articulo modificado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "El articulo no existe", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show()
        }
    }
}